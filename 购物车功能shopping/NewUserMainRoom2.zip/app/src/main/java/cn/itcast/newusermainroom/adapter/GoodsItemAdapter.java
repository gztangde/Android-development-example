package cn.itcast.newusermainroom.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itcast.newusermainroom.R;
import cn.itcast.newusermainroom.bean.FoodInfo;
import cn.itcast.newusermainroom.bean.GoodsSelected;
import cn.itcast.newusermainroom.util.TempData;

public class GoodsItemAdapter extends RecyclerView.Adapter<GoodsItemAdapter.ViewHolder> {
    List<FoodInfo> goodsList;
    final Context context;
    private TempData.CHashMap<Integer, GoodsSelected> map = new TempData.CHashMap<>();

    public GoodsItemAdapter(Context context, List<FoodInfo> goodsList) {
        this.context = context;
        this.goodsList = goodsList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_goods_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        FoodInfo foodInfo = goodsList.get(position);
        holder.cbSelectGoodsItem.setVisibility(View.GONE);
        holder.ivGoodsItem.setImageBitmap(BitmapFactory.decodeResource(context.getResources(), R.drawable.test));
        holder.tvGoodsTitle.setText(foodInfo.getFood_name());
        holder.tvGoodsMonthSold.setText(String.format(context.getString(R.string.month_sold), foodInfo.getFood_number()));
        holder.tvGoodsPrice.setText(String.format(context.getString(R.string.price), foodInfo.getFood_cost()));
        holder.tvItemCount.setText(foodInfo.getFood_count());
        if ("".equals(foodInfo.getFood_count()) || foodInfo.getFood_count() == null)
            holder.ivItemDecrease.setVisibility(View.GONE);
        else holder.ivItemDecrease.setVisibility(View.VISIBLE);
        holder.ivItemDecrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseCount(holder, position);
            }
        });
        holder.ivItemIncrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseCount(holder, position);
            }
        });
        System.out.println(holder.tvItemCount.getText().toString());
    }

    private void increaseCount(ViewHolder holder, int pos) {
        String count = holder.tvItemCount.getText().toString();
        FoodInfo foodInfo = goodsList.get(pos);
        int c;
        if (count.isEmpty()) {
            holder.tvItemCount.setText("1");
            holder.ivItemDecrease.setVisibility(View.VISIBLE);
            map.put(pos, new GoodsSelected(goodsList.get(pos), 1));
            foodInfo.setFood_count(1 + "");
            goodsList.set(pos, foodInfo);
        } else {
            c = Integer.parseInt(count);
            c++;
            holder.tvItemCount.setText(String.valueOf(c));
            foodInfo.setFood_count(c + "");
            goodsList.set(pos, foodInfo);
            GoodsSelected goodsSelected = map.get(pos);
            if (goodsSelected != null) {
                goodsSelected.setCount(c);
            }
        }
    }

    private void decreaseCount(ViewHolder holder, int pos) {
        String count = holder.tvItemCount.getText().toString();
        FoodInfo foodInfo = goodsList.get(pos);
        if (count.isEmpty() || "1".equals(count)) {
            holder.ivItemDecrease.setVisibility(View.GONE);
            holder.tvItemCount.setText("");
            foodInfo.setFood_count("");
            goodsList.set(pos, foodInfo);
            if (map.get(pos) != null) map.remove(pos);
        } else {
            int c = Integer.parseInt(count);
            c--;
            holder.tvItemCount.setText(String.valueOf(c));
            foodInfo.setFood_count(c + "");
            goodsList.set(pos, foodInfo);
            GoodsSelected goodsSelected = map.get(pos);
            if (goodsSelected != null) {
                goodsSelected.setCount(c);
            }
        }
    }

    @Override
    public int getItemCount() {
        return goodsList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        AppCompatCheckBox cbSelectGoodsItem;
        ImageView ivGoodsItem;
        ImageButton ivItemDecrease, ivItemIncrease;
        TextView tvItemCount, tvGoodsTitle, tvGoodsPrice, tvGoodsMonthSold;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cbSelectGoodsItem = itemView.findViewById(R.id.cbSelectGoodsItem);
            ivGoodsItem = itemView.findViewById(R.id.ivGoodsItem);
            ivItemDecrease = itemView.findViewById(R.id.ivItemDecrease);
            ivItemIncrease = itemView.findViewById(R.id.ivItemIncrease);
            tvItemCount = itemView.findViewById(R.id.tvItemCount);
            tvGoodsTitle = itemView.findViewById(R.id.tvGoodsTitle);
            tvGoodsPrice = itemView.findViewById(R.id.tvGoodsPrice);
            tvGoodsMonthSold = itemView.findViewById(R.id.tvGoodsMonthSold);
        }
    }

    public TempData.CHashMap<Integer, GoodsSelected> getData() {
        return map;
    }
}
