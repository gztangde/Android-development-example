package cn.itcast.newusermainroom;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import cn.itcast.newusermainroom.adapter.PageAdapter;
import cn.itcast.newusermainroom.fragment.FragmentCart;
import cn.itcast.newusermainroom.fragment.FragmentGoods;
import cn.itcast.newusermainroom.util.IStruct;

public class HomeActivity extends AppCompatActivity implements IStruct {
    private static final int TAB_NUM = 2; // 两个 tab
    private List<Fragment> fragments = new ArrayList<>();
    private String[] titles = new String[]{"商品", "购物车"};
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private PageAdapter adapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initComponent();
        initData();
        addListener();
    }

    @Override
    public void initComponent() {
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
    }

    @Override
    public void initData() {
        fragments.add(new FragmentGoods());
        fragments.add(new FragmentCart());
        adapter = new PageAdapter(fragments, titles, getSupportFragmentManager());
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setAdapter(adapter);
    }

    @Override
    public void addListener() {
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                for (int i = 0; i < titles.length; i++) {
                    if (tab == tabLayout.getTabAt(i)) {
                        viewPager.setCurrentItem(i);
                    }
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
