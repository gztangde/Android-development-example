package cn.itcast.newusermainroom.bean;

import java.io.Serializable;

public class FoodInfo implements Serializable {
    private String food_name;
    private String food_cost;
    private String food_number;
    private String food_count;
    private Boolean food_checked=false;

    public FoodInfo() {
    }

    @Override
    public String toString() {
        return "FoodInfo{" +
                "food_name='" + food_name + '\'' +
                ", food_cost='" + food_cost + '\'' +
                ", food_number='" + food_number + '\'' +
                ", food_count='" + food_count + '\'' +
                ", food_checked=" + food_checked +
                '}';
    }

    public String getFood_name() {
        return food_name;
    }

    public void setFood_name(String food_name) {
        this.food_name = food_name;
    }

    public String getFood_cost() {
        return food_cost;
    }

    public void setFood_cost(String food_cost) {
        this.food_cost = food_cost;
    }

    public String getFood_number() {
        return food_number;
    }

    public void setFood_number(String food_number) {
        this.food_number = food_number;
    }

    public String getFood_count() {
        return food_count;
    }

    public void setFood_count(String food_count) {
        this.food_count = food_count;
    }

    public Boolean getFood_checked() {
        return food_checked;
    }

    public void setFood_checked(Boolean food_checked) {
        this.food_checked = food_checked;
    }
}

