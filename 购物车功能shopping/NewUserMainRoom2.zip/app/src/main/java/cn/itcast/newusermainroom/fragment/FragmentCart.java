package cn.itcast.newusermainroom.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import cn.itcast.newusermainroom.util.IStruct;
import cn.itcast.newusermainroom.R;
import cn.itcast.newusermainroom.adapter.CartItemAdapter;
import cn.itcast.newusermainroom.bean.FoodInfo;
import cn.itcast.newusermainroom.bean.GoodsSelected;
import cn.itcast.newusermainroom.util.TempData;
import cn.itcast.newusermainroom.util.ToastUtil;

public class FragmentCart extends Fragment implements IStruct, CartItemAdapter.IOnItemStateUpdateListener {

    private static final String TAG = "FragmentCart";
    private RecyclerView recyclerView;
    private Button btnPay;
    private AppCompatCheckBox cbSelectAll;
    private TextView tvCount, tvTip;
    private List<FoodInfo> list;
    private float calCount = 0f;
    public static boolean isCheckedAll = false;
    private CartItemAdapter adapter;
    private TempData.CHashMap<Integer, GoodsSelected> tempMap;
    private boolean isCallBack = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated");
        initComponent();
        initData();
        addListener();
    }


    @Override
    public void initComponent() {
        recyclerView = getActivity().findViewById(R.id.recyclerviewCart);
        btnPay = getActivity().findViewById(R.id.btnPay);
        cbSelectAll = getActivity().findViewById(R.id.cbSelectAll);
        tvCount = getActivity().findViewById(R.id.tvCount);
        tvTip = getActivity().findViewById(R.id.tvTip);
    }

    @Override
    public void initData() {
        tvCount.setText(String.format(getActivity().getResources().getString(R.string.price_count), 0f));
    }


    @Override
    public void onResume() {
        super.onResume();
        list = handleCartData();
        if (list.size() > 0) {
            btnPay.setEnabled(true);
            tvTip.setVisibility(View.GONE);
            cbSelectAll.setEnabled(true);
        } else {
            cbSelectAll.setEnabled(false);
            btnPay.setEnabled(false);
            tvTip.setVisibility(View.VISIBLE);
        }
        cbSelectAll.setChecked(false);
        isCheckedAll = false;
        String str = String.format(getActivity().getResources().getString(R.string.price_count), 0f);
        tvCount.setText(str);
        adapter = new CartItemAdapter(getContext(), list);
        adapter.setListener(this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause");
        TempData.cacheCart(adapter.getData());
    }

    @Override
    public void addListener() {
        cbSelectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isChecked = cbSelectAll.isChecked();
                isCheckedAll = isChecked;
                List<FoodInfo> temp = new ArrayList<>();
                for (FoodInfo foodInfo : list) {
                    foodInfo.setFood_checked(isChecked);
                    calCount += Float.parseFloat(foodInfo.getFood_cost()) * Integer.parseInt(foodInfo.getFood_count());
                    temp.add(foodInfo);
                }
                if (!isChecked) {
                    calCount = 0f;
                }
                String str = String.format(getActivity().getResources().getString(R.string.price_count), calCount);
                tvCount.setText(str);
                adapter = new CartItemAdapter(getContext(), temp);
                adapter.setListener(FragmentCart.this);
                recyclerView.setAdapter(adapter);
                isCallBack = false;
            }
        });
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToastUtil.showMsg(getContext(), "已结算");
            }
        });
    }

    private List<FoodInfo> handleCartData() {
        List<FoodInfo> foodInfos = new ArrayList<>();

        tempMap = TempData.getData();
        for (TempData.CHashMap.Entry<Integer, GoodsSelected> entry : tempMap.entrySet()) {
            GoodsSelected goodsSelected = entry.getValue();
            FoodInfo foodInfo = goodsSelected.getFoodInfo();
            foodInfos.add(foodInfo);
        }
        return foodInfos;
    }

    @Override
    public void onStateUpdate(float f) {
        calCount += f;
        if (calCount < 0f) calCount = 0f;
        String str = String.format(getActivity().getResources().getString(R.string.price_count), calCount);
        tvCount.setText(str);
    }

    @Override
    public void onItemCheckedAll(boolean isCAll) {
        cbSelectAll.setChecked(isCAll);
        isCheckedAll = isCAll;
    }
}
