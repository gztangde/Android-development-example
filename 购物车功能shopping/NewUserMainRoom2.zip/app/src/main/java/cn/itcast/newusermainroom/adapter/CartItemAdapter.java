package cn.itcast.newusermainroom.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import cn.itcast.newusermainroom.R;
import cn.itcast.newusermainroom.bean.FoodInfo;
import cn.itcast.newusermainroom.fragment.FragmentCart;

public class CartItemAdapter extends RecyclerView.Adapter<CartItemAdapter.ViewHolder> {
    final List<FoodInfo> goodsList;
    List<Boolean> pos = new ArrayList<>();
    final Context context;
    private IOnItemStateUpdateListener listener;


    public void setListener(IOnItemStateUpdateListener listener) {
        this.listener = listener;
    }

    public CartItemAdapter(Context context, List<FoodInfo> goodsList) {
        this.context = context;
        this.goodsList = goodsList;
        for (int i = 0; i < goodsList.size(); i++) {
            pos.add(goodsList.get(i).getFood_checked());
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_cart_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        FoodInfo foodInfo = goodsList.get(position);
        if (!foodInfo.getFood_count().isEmpty())
            holder.ivItemDecrease.setVisibility(View.VISIBLE);
        if (FragmentCart.isCheckedAll) {
            foodInfo.setFood_checked(true);
        }
        holder.cbSelectGoodsItem.setChecked(foodInfo.getFood_checked());
        holder.ivGoodsItem.setImageBitmap(BitmapFactory.decodeResource(context.getResources(), R.drawable.test));
        holder.tvGoodsTitle.setText(foodInfo.getFood_name());
        holder.tvGoodsMonthSold.setText(String.format(context.getString(R.string.month_sold), foodInfo.getFood_number()));
        holder.tvGoodsPrice.setText(String.format(context.getString(R.string.price), foodInfo.getFood_cost()));
        holder.tvItemCount.setText(foodInfo.getFood_count());
        holder.cbSelectGoodsItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                checkItem(position, isChecked);
            }
        });
        holder.ivItemDecrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseCount(holder, position);
            }
        });
        holder.ivItemIncrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseCount(holder, position);
            }
        });
    }

    private void checkItem(int position, boolean isChecked) {
        FoodInfo foodInfo = goodsList.get(position);
        float f = 0f;
        if (!foodInfo.getFood_count().isEmpty())
            f = Float.parseFloat(foodInfo.getFood_cost()) * Integer.parseInt(foodInfo.getFood_count());
        if (isChecked) {
            listener.onStateUpdate(f);
        } else {
            listener.onStateUpdate(-f);
        }
        foodInfo.setFood_checked(isChecked);
        pos.set(position, isChecked);
        goodsList.set(position, foodInfo);
        listener.onItemCheckedAll(isCheckedAll());
    }

    private boolean isCheckedAll() {
        for (Boolean b : pos) {
            if (!b) return false;
        }
        return true;
    }

    private void increaseCount(ViewHolder holder, int pos) {
        String count = holder.tvItemCount.getText().toString();
        FoodInfo foodInfo = goodsList.get(pos);
        int c;
        if (count.isEmpty()) {
            holder.tvItemCount.setText("1");
            holder.ivItemDecrease.setVisibility(View.VISIBLE);
            holder.cbSelectGoodsItem.setVisibility(View.VISIBLE);
            foodInfo.setFood_count(1 + "");
        } else {
            c = Integer.parseInt(count);
            c++;
            holder.tvItemCount.setText(String.valueOf(c));
            foodInfo.setFood_count(c + "");
        }
        goodsList.set(pos, foodInfo);
        notifyItemChanged(pos);
        if (holder.cbSelectGoodsItem.isChecked()) {
            float f = Float.parseFloat(foodInfo.getFood_cost());
            listener.onStateUpdate(f);
        }
    }

    private void decreaseCount(ViewHolder holder, int pos) {
        String count = holder.tvItemCount.getText().toString();
        FoodInfo foodInfo = goodsList.get(pos);
        int c = Integer.parseInt(count);
        if ("1".equals(count) || count.isEmpty()) {
//            holder.ivItemDecrease.setVisibility(View.GONE);
//            holder.cbSelectGoodsItem.setVisibility(View.INVISIBLE);
//            holder.tvItemCount.setText("");
//            foodInfo.setFood_count("");
//            goodsList.set(pos, foodInfo);
            goodsList.remove(pos);
            notifyItemRemoved(pos);
        } else {
            c--;
            holder.tvItemCount.setText(String.valueOf(c));
            foodInfo.setFood_count(c + "");
            goodsList.set(pos, foodInfo);
            notifyItemChanged(pos);
        }
        if (holder.cbSelectGoodsItem.isChecked()) {
            float f = Float.parseFloat(foodInfo.getFood_cost());
            listener.onStateUpdate(-f);
        }
    }

    @Override
    public int getItemCount() {
        return goodsList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        AppCompatCheckBox cbSelectGoodsItem;
        ImageView ivGoodsItem;
        ImageButton ivItemDecrease, ivItemIncrease;
        TextView tvItemCount, tvGoodsTitle, tvGoodsPrice, tvGoodsMonthSold;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cbSelectGoodsItem = itemView.findViewById(R.id.cbSelectGoodsItem);
            ivGoodsItem = itemView.findViewById(R.id.ivGoodsItem);
            ivItemDecrease = itemView.findViewById(R.id.ivItemDecrease);
            ivItemIncrease = itemView.findViewById(R.id.ivItemIncrease);
            tvItemCount = itemView.findViewById(R.id.tvItemCount);
            tvGoodsTitle = itemView.findViewById(R.id.tvGoodsTitle);
            tvGoodsPrice = itemView.findViewById(R.id.tvGoodsPrice);
            tvGoodsMonthSold = itemView.findViewById(R.id.tvGoodsMonthSold);
        }
    }

    public List<FoodInfo> getData() {
        return goodsList;
    }

    public interface IOnItemStateUpdateListener {
        void onStateUpdate(float f);

        void onItemCheckedAll(boolean isCheckedAll);
    }

}
