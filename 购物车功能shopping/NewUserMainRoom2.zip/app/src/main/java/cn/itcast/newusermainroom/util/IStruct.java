package cn.itcast.newusermainroom.util;

public interface IStruct {
    void initComponent();

    void initData();

    void addListener();
}
