package cn.itcast.newusermainroom.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import cn.itcast.newusermainroom.R;
import cn.itcast.newusermainroom.adapter.GoodsItemAdapter;
import cn.itcast.newusermainroom.bean.FoodInfo;
import cn.itcast.newusermainroom.bean.GoodsSelected;
import cn.itcast.newusermainroom.util.NetworkUtil;
import cn.itcast.newusermainroom.util.TempData;
import cn.itcast.newusermainroom.util.ToastUtil;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class FragmentGoods extends Fragment {
    private static final String TAG = "FragmentGoods";
    private ArrayList<FoodInfo> list;
    private RecyclerView recyclerView;
    private GoodsItemAdapter adapter;
    private Handler handler = new MHandler();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (container == null) return null;
        return inflater.inflate(R.layout.fragment_goods, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initData();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerviewGoods);
        Button btnAddToCart = view.findViewById(R.id.btnAddToCart);
        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TempData.CHashMap<Integer, GoodsSelected> map = adapter.getData();
                if (map.size() > 0) {
                    TempData.cache(map);
                    ToastUtil.showMsg(getContext(), "已添加到购物车");
                }
            }
        });
    }

    public void initData() {
        new Thread((new Runnable() {
            @Override
            public void run() {
                OkHttpClient okHttpClient = new OkHttpClient();
                //服务器返回的地址
                Request request = new Request.Builder().url("http://123.57.79.31:8000/storefood/s01/").build();
                try {
                    Response response = okHttpClient.newCall(request).execute();
                    //获取到数据
                    String data = response.body().string();
                    //在线程中没有办法实现主线程操作
                    Message message = new Message();
                    message.what = 1;
                    handler.sendMessage(message);
                    //把数据传入解析json数据方法
                    Gsonjx(data);
                } catch (IOException e) {
                    Message message = new Message();
                    message.what = 0;
                    handler.sendMessage(message);
                }
            }
        })).start();
    }

    private void Gsonjx(String date) {
        JsonParser parser = new JsonParser();
        JsonArray jsonArray = parser.parse(date).getAsJsonArray();
        Gson gson = new Gson();
        list = new ArrayList<>();
        for (JsonElement FoodInfo : jsonArray) {
            FoodInfo userBean = gson.fromJson(FoodInfo, FoodInfo.class);
            list.add(userBean);
        }
        Message message = new Message();
        message.what = 2;
        handler.sendMessage(message);
    }

    class MHandler extends Handler {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (msg.what == 2) {
                adapter = new GoodsItemAdapter(getContext(), list);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setAdapter(adapter);
            } else if (msg.what == 0) {
                ToastUtil.showMsg(getContext(), "没有网络，请检查网络设置~");
                sendEmptyMessageDelayed(4, 3000);
            } else if (msg.what == 4) {
                getActivity().finish();
            }
        }
    }
}
