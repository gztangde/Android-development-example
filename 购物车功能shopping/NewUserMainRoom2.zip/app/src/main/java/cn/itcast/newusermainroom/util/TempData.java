package cn.itcast.newusermainroom.util;

import androidx.annotation.NonNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itcast.newusermainroom.bean.FoodInfo;
import cn.itcast.newusermainroom.bean.GoodsSelected;

public class TempData {
    private static CHashMap<Integer, GoodsSelected> temp;
    private static List<FoodInfo> tempCartData;


    public static void cache(CHashMap<Integer, GoodsSelected> cache) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(cache);
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            // 反序列化
            ObjectInputStream ois = new ObjectInputStream(bais);
            temp = (CHashMap<Integer, GoodsSelected>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void cacheCart(List<FoodInfo> data) {
        tempCartData = data;
    }

    public static List<FoodInfo> getCartData() {
        if (tempCartData == null) tempCartData = new ArrayList<>();
        return tempCartData;
    }

    public static void clearCart() {
        tempCartData = null;
    }

    public static CHashMap<Integer, GoodsSelected> getData() {
        if (temp == null) temp = new CHashMap<>();

        return temp;
    }

    public static class CHashMap<Integer, GoodsSelected> extends HashMap<Integer, GoodsSelected> implements Serializable {

    }
}
