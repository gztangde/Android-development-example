package cn.itcast.newusermainroom.bean;

import java.io.Serializable;

public class GoodsSelected implements Serializable {
    private FoodInfo foodInfo;
    private Integer count;

    public GoodsSelected() {
    }

    public GoodsSelected(FoodInfo foodInfo, Integer count) {
        this.foodInfo = foodInfo;
        this.count = count;
    }

    public FoodInfo getFoodInfo() {
        return foodInfo;
    }

    public void setFoodInfo(FoodInfo foodInfo) {
        this.foodInfo = foodInfo;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
