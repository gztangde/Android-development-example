package cn.itcast.newusermainroom.activity;

import androidx.appcompat.app.AppCompatActivity;



import java.io.IOException;
import java.util.ArrayList;

import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import cn.itcast.newusermainroom.R;
import cn.itcast.newusermainroom.adapter.FoodAdapter;
import cn.itcast.newusermainroom.bean.FoodInfo;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    public String data;
    public ListView lv;
    public ArrayList<FoodInfo> listfood;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView)findViewById(R.id.lv);
        init();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this,""+listfood.get(position).getFood_name(),Toast.LENGTH_LONG).show();
            }
        });
    }
    private void init(){
        new Thread((new Runnable() {
            @Override
            public void run() {
                OkHttpClient okHttpClient = new OkHttpClient();
                //服务器返回的地址
                Request request =new Request.Builder().url("http://123.57.79.31:8000/storefood/s01/").build();
                try{
                    Response response = okHttpClient.newCall(request).execute();
                    //获取到数据
                    data =response.body().string();
                    //在线程中没有办法实现主线程操作
                    Message message = new Message();
                    message.what = 1;
                    han.sendMessage(message);
                    //把数据传入解析json数据方法
                    GsonParse(data);
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        })).start();
    }
    public android.os.Handler han = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg){
            switch (msg.what){
                case 1:
                    Toast.makeText(MainActivity.this,""+data,Toast.LENGTH_LONG).show();
                    break;
                case 2:
                    lv.setAdapter(new FoodAdapter(MainActivity.this,listfood));//调用listfood适配器
            }
        }
    };
    private void GsonParse(String date){
        JsonParser parser = new JsonParser();
        JsonArray jsonArray = parser.parse(date).getAsJsonArray();
        Gson gson = new Gson();
        listfood = new ArrayList<>();
        for(JsonElement FoodInfo:jsonArray){
            FoodInfo userBean = gson.fromJson(FoodInfo,FoodInfo.class);
            listfood.add(userBean);
        }
        Message message = new Message();
        message.what = 2;
        han.sendMessage(message);
    }
}
