package cn.itcast.newusermainroom.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

import cn.itcast.newusermainroom.bean.FoodInfo;
import cn.itcast.newusermainroom.R;

public class FoodAdapter extends BaseAdapter {
    public Context con;
    public List<FoodInfo> list;
    public LayoutInflater inflater;
    public FoodAdapter(Context context,List<FoodInfo> FoodInfo){
        this.con = context;
        this.list = FoodInfo;
        inflater = LayoutInflater.from(con);
    }
    @Override
    public int getCount(){
        return list.size();
    }
    @Override
    public Object getItem(int position){
        return list.get(position);
    }
    @Override
    public long getItemId(int position){
        return position;
    }
    @Override
    public View getView(int position,View convertView,ViewGroup parent){
        View view = inflater.inflate(R.layout.list_item,null);
        TextView tv_name = (TextView)view.findViewById(R.id.tv_name);
        TextView tv_sell = (TextView)view.findViewById(R.id.tv_sell);
        TextView tv_price= (TextView)view.findViewById(R.id.tv_price);
        ImageView img =(ImageView)view.findViewById(R.id.tv_pic);
        tv_name.setText(list.get(position).getFood_name());
        tv_price.setText("价格："+list.get(position).getFood_cost());
        tv_sell.setText("月售："+list.get(position).getFood_number());
        return view;
    }
}
